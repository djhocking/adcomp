/* $Id: Rosen34.h 1369 2009-05-31 01:31:48Z bradbell $ */
# include "cppad/rosen_34.hpp"
